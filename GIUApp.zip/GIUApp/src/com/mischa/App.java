package com.mischa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App {
    private JButton LoginButton;
    private JPanel MainPanel;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JFrame loginFrame;


    public App() {
        LoginButton.addActionListener(e -> {
//            this.loginFrame.dispose();
            JFrame dashboard = new Dashboard();
        });
    }

    private void createUIComponents() {
        this._crateLoginFrame();

    }


    public static void main(String[] args) {

        new App().createUIComponents();
    }

    private void _crateLoginFrame() {
        this.loginFrame = new JFrame("App");
        this.loginFrame.add(LoginButton);
        this.loginFrame.setContentPane(new App().MainPanel);
        this.loginFrame.setDefaultCloseOperation(loginFrame.EXIT_ON_CLOSE);
        this.loginFrame.pack();
        this.loginFrame.setResizable(false);
        this.loginFrame.setSize(300, 200);
        this.loginFrame.setVisible(true);
        this.loginFrame.getContentPane().setBackground(new Color(0xFFFFFF));
    }
}
