package com.mischa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Dashboard extends JFrame {

    private JPanel dashboardapp;
    private JProgressBar humidityprogress;
    private JProgressBar temperatureprogress;
    private JProgressBar sunlightprogress;
    private JLabel humidity;
    private JLabel sunlight;
    private JLabel temperature;
    private JComboBox comboBox;
    private JPanel tweedePanel;
    private String userID;
    private JLabel background;

    public void createUIComponents() {


        ImageIcon img = new ImageIcon("background.JPG");
        JLabel background = new JLabel();
        background.setBounds(0,0,618,218);
        background.setIcon(img);
//        dashboardapp.add(background);

        comboBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
            }
        });

        this.add(dashboardapp);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);


    }

    public Dashboard() {
        this.createUIComponents();
    }

    public static void main(String[] args) {
        Dashboard f = new Dashboard();

    }
}
